
📌 Instruções de Deploy

1. Baixe e descompacte a pasta `pgsoft_backend`
2. No terminal (Termux ou PC):
   npm install
3. Crie arquivo .env baseado em .env.example
4. Rodar local: node server.js
5. Subir para Railway:
   - Criar repositório GitHub e enviar os arquivos
   - Conectar no Railway (Deploy from GitHub)
   - Adicionar variáveis de ambiente no Railway
